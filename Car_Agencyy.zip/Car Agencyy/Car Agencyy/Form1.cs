﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Car_Agencyy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = usernameTB.Text;
            string password = passwordTB.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))   ///// input validation /////
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error");  //// error message ///
                return;
            }

            if (username == "admin" && password == "12345")
            {
                Main_Menu m = new Main_Menu(); 
                m.Show();   ///// go to main menu form /////
            }
            else
            {
                MessageBox.Show("Username or password is incorrect.", "Authentication Failed");   //// error message ///
            }
        }
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();   //// exit program ////
        }
    }
}

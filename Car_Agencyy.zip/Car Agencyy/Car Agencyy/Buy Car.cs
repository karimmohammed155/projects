﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Agencyy
{
    public partial class Buy_Car : Form
    {
        class car
        {
            public double pr;

            public car()
            {
                pr = 0;
            }
            public car(double price)
            {
                pr = price;
            }
            public double total_price(double pr)   /// function returns total price from class car ///
            {
                return pr;
            }
        }
            public Buy_Car()
        {
            InitializeComponent();
        }

        private void SelectCarBtn_Click(object sender, EventArgs e)
        {
            double price = 0;
            car c = new car();

                   /// if/else statment of car list and it's type with price ///

            if (lB1.SelectedItem.ToString() == "BMW 1 Series " && manual.Checked)
            {
                price = 500000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW 1 Series " && automatic.Checked)
            {
                price = 520000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X3 " && manual.Checked)
            {
                price = 600000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X3 " && automatic.Checked)
            {
                price = 620000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X5 " && manual.Checked)
            {
                price = 800000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X5 " && automatic.Checked)
            {
                price = 820000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X6 " && manual.Checked)
            {
                price = 1000000;
            }
            else if (lB1.SelectedItem.ToString() == "BMW X6 " && automatic.Checked)
            {
                price = 1020000;
            }
            else if (lB1.SelectedItem.ToString() == "M3 sedan" && manual.Checked)
            {
                price = 900000;
            }
            else if (lB1.SelectedItem.ToString() == "M3 sedan" && automatic.Checked)
            {
                price = 920000;
            }
            else if (lB1.SelectedItem.ToString() == "M4 coupe " && manual.Checked)
            {
                price = 700000;
            }
            else if (lB1.SelectedItem.ToString() == "M4 coupe " && automatic.Checked)
            {
                price = 720000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz C-Class" && manual.Checked)
            {
                price = 2000000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz C-Class" && automatic.Checked)
            {
                price = 2020000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz E-Class" && manual.Checked)
            {
                price = 3000000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz E-Class" && automatic.Checked)
            {
                price = 3030000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz S-Class" && manual.Checked)
            {
                price = 4000000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz S-Class" && automatic.Checked)
            {
                price = 4020000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz CLA-Class" && manual.Checked)
            {
                price = 5000000;
            }
            else if (lB1.SelectedItem.ToString() == "Mercedes-Benz CLA-Class" && automatic.Checked)
            {
                price = 5020000;
            }
            else
            {
                MessageBox.Show("please select a car or type correctly");
            }
            totalpriceTb.Text = c.total_price(price).ToString("c"); /// displays total price in textbox ///
        }

        private void BuyBtn_Click(object sender, EventArgs e)
        {
            /// if/else statment for payment type ///
            if (cash.Checked)
            {
                MessageBox.Show("you choose to pay with Cash");
                this.Close();
            }
            else if (visa.Checked)
            {
                MessageBox.Show("you choose to pay with Visa");
                this.Close();
            }
            else
            {
                MessageBox.Show("choose your credit");
            }
        }

    }
}

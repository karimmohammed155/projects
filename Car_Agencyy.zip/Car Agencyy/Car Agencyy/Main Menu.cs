﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Agencyy
{
    public partial class Main_Menu : Form
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void BuyFormBtn_Click(object sender, EventArgs e)
        {

            Buy_Car m = new Buy_Car();
            m.Show();   ///// go to buy car form /////

        }

        private void RentFormBtn_Click(object sender, EventArgs e)
        {
            Car_Rent m = new Car_Rent();
            m.Show();  ///// go to car rent form /////
        }
        private void CarsDataFormBtn_Click(object sender, EventArgs e)
        {
                Cars_Data m = new Cars_Data();
                m.Show();  ///// go to cars data form /////
        }
        private void CustomersDataBtn_Click_1(object sender, EventArgs e)
        {
            customersdata m = new customersdata();
            m.Show();   ///// go to customers data form /////
        }
        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

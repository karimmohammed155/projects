﻿namespace Car_Agencyy
{


    partial class carstoreDataSet
    {
    }
}


﻿namespace Car_Agencyy
{
    partial class Buy_Car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lB1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.automatic = new System.Windows.Forms.RadioButton();
            this.manual = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.visa = new System.Windows.Forms.RadioButton();
            this.cash = new System.Windows.Forms.RadioButton();
            this.BuyBtn = new System.Windows.Forms.Button();
            this.SelectCarBtn = new System.Windows.Forms.Button();
            this.totalpriceTb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lB1
            // 
            this.lB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lB1.FormattingEnabled = true;
            this.lB1.ItemHeight = 25;
            this.lB1.Items.AddRange(new object[] {
            "BMW 1 Series ",
            "BMW X3 ",
            "BMW X5 ",
            "BMW X6 ",
            "M3 sedan",
            "M4 coupe ",
            "Mercedes-Benz C-Class",
            "Mercedes-Benz E-Class",
            "Mercedes-Benz S-Class",
            "Mercedes-Benz CLA-Class"});
            this.lB1.Location = new System.Drawing.Point(22, 96);
            this.lB1.Margin = new System.Windows.Forms.Padding(4);
            this.lB1.Name = "lB1";
            this.lB1.Size = new System.Drawing.Size(350, 304);
            this.lB1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.automatic);
            this.groupBox1.Controls.Add(this.manual);
            this.groupBox1.Location = new System.Drawing.Point(516, 96);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(250, 125);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Type";
            // 
            // automatic
            // 
            this.automatic.AutoSize = true;
            this.automatic.Location = new System.Drawing.Point(42, 83);
            this.automatic.Margin = new System.Windows.Forms.Padding(4);
            this.automatic.Name = "automatic";
            this.automatic.Size = new System.Drawing.Size(105, 24);
            this.automatic.TabIndex = 1;
            this.automatic.TabStop = true;
            this.automatic.Text = "Automatic";
            this.automatic.UseVisualStyleBackColor = true;
            // 
            // manual
            // 
            this.manual.AutoSize = true;
            this.manual.Location = new System.Drawing.Point(42, 42);
            this.manual.Margin = new System.Windows.Forms.Padding(4);
            this.manual.Name = "manual";
            this.manual.Size = new System.Drawing.Size(84, 24);
            this.manual.TabIndex = 0;
            this.manual.TabStop = true;
            this.manual.Text = "Manual";
            this.manual.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.visa);
            this.groupBox2.Controls.Add(this.cash);
            this.groupBox2.Controls.Add(this.BuyBtn);
            this.groupBox2.Location = new System.Drawing.Point(516, 308);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(250, 195);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Credit";
            // 
            // visa
            // 
            this.visa.AutoSize = true;
            this.visa.Location = new System.Drawing.Point(42, 93);
            this.visa.Name = "visa";
            this.visa.Size = new System.Drawing.Size(63, 24);
            this.visa.TabIndex = 7;
            this.visa.TabStop = true;
            this.visa.Text = "Visa";
            this.visa.UseVisualStyleBackColor = true;
            // 
            // cash
            // 
            this.cash.AutoSize = true;
            this.cash.Location = new System.Drawing.Point(42, 51);
            this.cash.Name = "cash";
            this.cash.Size = new System.Drawing.Size(69, 24);
            this.cash.TabIndex = 6;
            this.cash.TabStop = true;
            this.cash.Text = "Cash";
            this.cash.UseVisualStyleBackColor = true;
            // 
            // BuyBtn
            // 
            this.BuyBtn.Location = new System.Drawing.Point(55, 135);
            this.BuyBtn.Margin = new System.Windows.Forms.Padding(4);
            this.BuyBtn.Name = "BuyBtn";
            this.BuyBtn.Size = new System.Drawing.Size(122, 42);
            this.BuyBtn.TabIndex = 5;
            this.BuyBtn.Text = "Buy";
            this.BuyBtn.UseVisualStyleBackColor = true;
            this.BuyBtn.Click += new System.EventHandler(this.BuyBtn_Click);
            // 
            // SelectCarBtn
            // 
            this.SelectCarBtn.Location = new System.Drawing.Point(184, 457);
            this.SelectCarBtn.Margin = new System.Windows.Forms.Padding(4);
            this.SelectCarBtn.Name = "SelectCarBtn";
            this.SelectCarBtn.Size = new System.Drawing.Size(120, 46);
            this.SelectCarBtn.TabIndex = 4;
            this.SelectCarBtn.Text = "Select Car";
            this.SelectCarBtn.UseVisualStyleBackColor = true;
            this.SelectCarBtn.Click += new System.EventHandler(this.SelectCarBtn_Click);
            // 
            // totalpriceTb
            // 
            this.totalpriceTb.Location = new System.Drawing.Point(603, 252);
            this.totalpriceTb.Margin = new System.Windows.Forms.Padding(4);
            this.totalpriceTb.Name = "totalpriceTb";
            this.totalpriceTb.Size = new System.Drawing.Size(163, 27);
            this.totalpriceTb.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(493, 255);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Total Price :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(59, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 32);
            this.label2.TabIndex = 7;
            this.label2.Text = "Choose a car :";
            // 
            // Buy_Car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(850, 562);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.totalpriceTb);
            this.Controls.Add(this.SelectCarBtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lB1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Buy_Car";
            this.Text = "Buy_Car";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lB1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton automatic;
        private System.Windows.Forms.RadioButton manual;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button SelectCarBtn;
        private System.Windows.Forms.Button BuyBtn;
        private System.Windows.Forms.TextBox totalpriceTb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton visa;
        private System.Windows.Forms.RadioButton cash;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Agencyy
{
    public partial class customersdata : Form
    {
        public customersdata()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.carstoreDataSet);

        }

        private void customersdata_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'carstoreDataSet.customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.carstoreDataSet.customers);

        }

        private void searchNameToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.customersTableAdapter.SearchName(this.carstoreDataSet.customers, nameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}

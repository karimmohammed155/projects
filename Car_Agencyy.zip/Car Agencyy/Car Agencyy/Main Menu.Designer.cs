﻿namespace Car_Agencyy
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BuyFormBtn = new System.Windows.Forms.Button();
            this.RentFormBtn = new System.Windows.Forms.Button();
            this.CarsDataFormBtn = new System.Windows.Forms.Button();
            this.LogoutBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomersDataBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BuyFormBtn
            // 
            this.BuyFormBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BuyFormBtn.Location = new System.Drawing.Point(108, 98);
            this.BuyFormBtn.Name = "BuyFormBtn";
            this.BuyFormBtn.Size = new System.Drawing.Size(151, 49);
            this.BuyFormBtn.TabIndex = 0;
            this.BuyFormBtn.Text = "Buy Car";
            this.BuyFormBtn.UseVisualStyleBackColor = true;
            this.BuyFormBtn.Click += new System.EventHandler(this.BuyFormBtn_Click);
            // 
            // RentFormBtn
            // 
            this.RentFormBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RentFormBtn.Location = new System.Drawing.Point(108, 189);
            this.RentFormBtn.Name = "RentFormBtn";
            this.RentFormBtn.Size = new System.Drawing.Size(151, 49);
            this.RentFormBtn.TabIndex = 1;
            this.RentFormBtn.Text = "Car Rent";
            this.RentFormBtn.UseVisualStyleBackColor = true;
            this.RentFormBtn.Click += new System.EventHandler(this.RentFormBtn_Click);
            // 
            // CarsDataFormBtn
            // 
            this.CarsDataFormBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CarsDataFormBtn.Location = new System.Drawing.Point(108, 278);
            this.CarsDataFormBtn.Name = "CarsDataFormBtn";
            this.CarsDataFormBtn.Size = new System.Drawing.Size(151, 49);
            this.CarsDataFormBtn.TabIndex = 2;
            this.CarsDataFormBtn.Text = "Cars Data";
            this.CarsDataFormBtn.UseVisualStyleBackColor = true;
            this.CarsDataFormBtn.Click += new System.EventHandler(this.CarsDataFormBtn_Click);
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoutBtn.Location = new System.Drawing.Point(108, 441);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(151, 49);
            this.LogoutBtn.TabIndex = 3;
            this.LogoutBtn.Text = "Log Out";
            this.LogoutBtn.UseVisualStyleBackColor = true;
            this.LogoutBtn.Click += new System.EventHandler(this.LogoutBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(65, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Car Agency System";
            // 
            // CustomersDataBtn
            // 
            this.CustomersDataBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersDataBtn.Location = new System.Drawing.Point(108, 360);
            this.CustomersDataBtn.Name = "CustomersDataBtn";
            this.CustomersDataBtn.Size = new System.Drawing.Size(151, 49);
            this.CustomersDataBtn.TabIndex = 5;
            this.CustomersDataBtn.Text = "CustomersData";
            this.CustomersDataBtn.UseVisualStyleBackColor = true;
            this.CustomersDataBtn.Click += new System.EventHandler(this.CustomersDataBtn_Click_1);
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(359, 519);
            this.Controls.Add(this.CustomersDataBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LogoutBtn);
            this.Controls.Add(this.CarsDataFormBtn);
            this.Controls.Add(this.RentFormBtn);
            this.Controls.Add(this.BuyFormBtn);
            this.Name = "Main_Menu";
            this.Text = "Main_Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BuyFormBtn;
        private System.Windows.Forms.Button RentFormBtn;
        private System.Windows.Forms.Button CarsDataFormBtn;
        private System.Windows.Forms.Button LogoutBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CustomersDataBtn;
    }
}
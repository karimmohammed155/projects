﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Agencyy
{
    public partial class Car_Rent : Form
    {
        class Car
        {
            public double pr;

            public Car()
            {
                pr = 0;
            }
            public Car(double price)
            {
                pr = price;
            }
            public double Total_price(double pr)   /// function returns total price from class car ///
            {
                return pr;
            }
        }
            public Car_Rent()
        {
            InitializeComponent();
        }

        private void SelectCarBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double price = 0;
                Car c = new Car();

                /// if/else statment of car list and it's type with price ///
 
                if (lB1.SelectedItem.ToString() == "BMW 1 Series " && manual.Checked)
                {
                    price = 500000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW 1 Series " && automatic.Checked)
                {
                    price = 520000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X3 " && manual.Checked)
                {
                    price = 600000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X3 " && automatic.Checked)
                {
                    price = 620000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X5 " && manual.Checked)
                {
                    price = 800000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X5 " && automatic.Checked)
                {
                    price = 820000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X6 " && manual.Checked)
                {
                    price = 1000000;
                }
                else if (lB1.SelectedItem.ToString() == "BMW X6 " && automatic.Checked)
                {
                    price = 1020000;
                }
                else if (lB1.SelectedItem.ToString() == "M3 sedan" && manual.Checked)
                {
                    price = 900000;
                }
                else if (lB1.SelectedItem.ToString() == "M3 sedan" && automatic.Checked)
                {
                    price = 920000;
                }
                else if (lB1.SelectedItem.ToString() == "M4 coupe " && manual.Checked)
                {
                    price = 700000;
                }
                else if (lB1.SelectedItem.ToString() == "M4 coupe " && automatic.Checked)
                {
                    price = 720000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz C-Class" && manual.Checked)
                {
                    price = 2000000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz C-Class" && automatic.Checked)
                {
                    price = 2020000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz E-Class" && manual.Checked)
                {
                    price = 3000000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz E-Class" && automatic.Checked)
                {
                    price = 3030000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz S-Class" && manual.Checked)
                {
                    price = 4000000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz S-Class" && automatic.Checked)
                {
                    price = 4020000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz CLA-Class" && manual.Checked)
                {
                    price = 5000000;
                }
                else if (lB1.SelectedItem.ToString() == "Mercedes-Benz CLA-Class" && automatic.Checked)
                {
                    price = 5020000;
                }
                else
                {
                    MessageBox.Show("please select the type correctly");
                }

                /// if/else statment of time duration of rent with price ///

                if (lB2.SelectedItem.ToString() == "1 week")
                {
                    price *= 0.02;
                }
                else if (lB2.SelectedItem.ToString() == "2 weeks")
                {
                    price *= 0.04;
                }
                else if (lB2.SelectedItem.ToString() == "3 weeks")
                {
                    price *= 0.06;
                }
                else if (lB2.SelectedItem.ToString() == "4 weeks")
                {
                    price *= 0.08;
                }
                else if (lB2.SelectedItem.ToString() == "5 weeks")
                {
                    price *= 0.1;
                }
                TotalpriceTb.Text = c.Total_price(price).ToString("c"); /// displays total price in textbox ///
            }
            catch (Exception) /// exception handling to handle if something is not selected /// 
            {
                MessageBox.Show("you have to fill in all the data");
            }
        }

        private void RentBtn_Click(object sender, EventArgs e)
        {
            /// if/else statment for payment type ///
            if (cash.Checked)
            {
                MessageBox.Show("you choose to pay with Cash");
                this.Close();
            }
            else if (visa.Checked)
            {
                MessageBox.Show("you choose to pay with Visa");
                this.Close();
            }
            else
            {
                MessageBox.Show("choose your credit");
            }
        }
    }
}
